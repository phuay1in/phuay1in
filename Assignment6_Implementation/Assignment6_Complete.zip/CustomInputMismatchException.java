import java.util.InputMismatchException;

//Custom exception class for input mismatches
public class CustomInputMismatchException extends Exception {
    
    public CustomInputMismatchException() {
        super("Invalid input. Please enter the correct data type.");
    }

    public CustomInputMismatchException(String message) {
        super(message);
    }

    public CustomInputMismatchException(InputMismatchException cause) {
        super("Invalid input. Please enter the correct data type.", cause);
    }
}