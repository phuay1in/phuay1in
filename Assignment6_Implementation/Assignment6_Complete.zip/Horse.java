import java.util.Objects;

public class Horse implements Animal {
	
	//instance variables
	private String name;
    private int age;
    private String species;
    private String color;
    
    //constructor
    public Horse(String name, int age, String species, String color) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
    }

    @Override
	public void move() {
    	System.out.println("The horse is moving");
    }
	
    @Override
	public void makeSound() {
    	System.out.println("Neighhh Neighh.");
    }

    @Override
	public String getName() {
    	return this.name;
    }

    @Override
	public int getAge() {
    	return this.age;
    }
  
    @Override
	public boolean equals(Object obj) {
		// Check for reference equality
    	if (this == obj) {
    		return true;
    	}
		// Check for null or different class
    	if (obj == null || this.getClass() != obj.getClass()) {
    		return false;
    	}
		// Compare fields for logical equality	 
    	Horse other = (Horse) obj;
    	 return age == other.age &&
    	           Objects.equals(name, other.name) &&
    	           Objects.equals(species, other.species) &&
    	           Objects.equals(color, other.color);
    }
    
    @Override
	public String toString() {
    	return String.format("Name: %s, Age: %d, Species: %s, Color: %s", name, age, species, color);
    }
 
}
