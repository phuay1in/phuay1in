/*
 * Class: CMSC203 
 * Instructor: Farnaz Eivazi
 * Description: Driver for the circus
 * Due: MM/DD/YYYY
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  
 * assignment independently. I have not copied the code 
 * from a student or any source. I have not given my code 
 * to any student.
   Print your Name here: Paul Huaylinos
*/


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class CircusDriverAppJUnitTest {
    private Circus circus;

    @BeforeEach
    void setUp() {
        circus = new Circus();
    }

    @Test
    void testAddDog() {
        Dog dog = new Dog("Shila", 3, "Golden Retriever", "Brown");
        circus.addAnimal(dog);
        List<Animal> animals = circus.getAnimals();
        assertEquals(1, animals.size());
        assertTrue(animals.get(0) instanceof Dog);
        assertEquals("Shila", animals.get(0).getName());
    }

    @Test
    void testAddBird() {
        Bird bird = new Bird("Tweety", 1, "Canary", "Yellow");
        circus.addAnimal(bird);
        List<Animal> animals = circus.getAnimals();
        assertEquals(1, animals.size());
        assertTrue(animals.get(0) instanceof Bird);
        assertEquals("Tweety", animals.get(0).getName());
    }

    @Test
    void testDisplayAnimals() {
        Dog dog = new Dog("Rex", 4, "Husky", "Gray");
        Bird bird = new Bird("Polly", 2, "Parrot", "Green");
        circus.addAnimal(dog);
        circus.addAnimal(bird);

        List<Animal> animals = circus.getAnimals();
        assertEquals(2, animals.size());
        // verify both animals are present by name
        assertEquals("Rex", animals.get(0).getName());
        assertEquals("Polly", animals.get(1).getName());
    }

    @Test
    void testSortAnimalsByAge() {
        Dog a = new Dog("Oldie", 8, "BreedA", "Tan");
        Bird b = new Bird("Young", 1, "BreedB", "Blue");
        Horse c = new Horse("Middle", 4, "BreedC", "Brown");

        circus.addAnimal(a);
        circus.addAnimal(b);
        circus.addAnimal(c);

        circus.sortAnimalsByAge();

        List<Animal> sorted = circus.getAnimals();
        assertEquals(3, sorted.size());
        assertEquals("Young", sorted.get(0).getName());   // age 1
        assertEquals("Middle", sorted.get(1).getName());  // age 4
        assertEquals("Oldie", sorted.get(2).getName());   // age 8
    }

    @Test
    void testSortAnimalsByName() {
        Dog d1 = new Dog("Charlie", 3, "Breed1", "Black");
        Bird d2 = new Bird("Alpha", 2, "Breed2", "White");
        Horse d3 = new Horse("Bravo", 5, "Breed3", "Brown");

        circus.addAnimal(d1);
        circus.addAnimal(d2);
        circus.addAnimal(d3);

        circus.sortAnimalsByName();

        List<Animal> sorted = circus.getAnimals();
        assertEquals(3, sorted.size());
        assertEquals("Alpha", sorted.get(0).getName());
        assertEquals("Bravo", sorted.get(1).getName());
        assertEquals("Charlie", sorted.get(2).getName());
    }

    @Test
    void testSearchAnimalByName() {
        Dog dog = new Dog("Rex", 4, "Husky", "Gray");
        circus.addAnimal(dog);

        Animal found = circus.searchAnimalByName("Rex");
        assertNotNull(found);
        assertEquals("Rex", found.getName());

        // case-insensitive search (your Circus implementation used equalsIgnoreCase)
        Animal found2 = circus.searchAnimalByName("rex");
        assertNotNull(found2);
        assertEquals("Rex", found2.getName());

        Animal notFound = circus.searchAnimalByName("Nope");
        assertNull(notFound);
    }

    @Test
    void testAddAndDisplayTickets() {
        // generateTicket should add a Ticket to the Circus tickets list
        Ticket t = circus.generateTicket("MONDAY", 20.0, 30);
        assertNotNull(t);

        List<Ticket> tickets = circus.getTickets();
        assertEquals(1, tickets.size());
        assertSame(t, tickets.get(0));
    }
}