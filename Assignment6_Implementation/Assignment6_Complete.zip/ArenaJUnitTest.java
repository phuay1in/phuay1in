import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ArenaJUnitTest {

    private Arena arena;

    @BeforeEach
    void setUp() {
        arena = new Arena("Blue", 100.0, 50.0);
    }

    @Test
    void testConstructorAndInitialValues() {
        assertEquals("Blue", arena.getColor(), "Initial color is incorrect.");
        assertEquals(100.0, arena.getLength(), 0.001, "Initial length is incorrect.");
        assertEquals(50.0, arena.getWidth(), 0.001, "Initial width is incorrect.");
        assertEquals("Arena", arena.getBuildingType(), "Initial building type is incorrect.");
    }

    @Test
    void testSetSize() {
        arena.setSize(200.5, 75.25);
        assertEquals(200.5, arena.getLength(), 0.001, "Length not updated correctly by setSize.");
        assertEquals(75.25, arena.getWidth(), 0.001, "Width not updated correctly by setSize.");
    }

    @Test
    void testSetColor() {
        arena.setColor("Red");
        assertEquals("Red", arena.getColor(), "Color not updated correctly by setColor.");
    }

    @Test
    void testSetBuildingType() {
        arena.setBuildingType("Stadium");
        assertEquals("Stadium", arena.getBuildingType(), "Building type not updated correctly by setBuildingType.");
    }

    @Test
    void testToString() {
        arena.setColor("Green");
        arena.setSize(123.45, 67.89);
        arena.setBuildingType("Big Arena");

        String expected = String.format("Building Type: %s, Color: %s, Length: %.2f, Width: %.2f",
                arena.getBuildingType(), arena.getColor(), arena.getLength(), arena.getWidth());

        assertEquals(expected, arena.toString(), "toString() output does not match expected format.");
    }
}