import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TicketingOfficeJUnitTest {

    private TicketingOffice office;

    @BeforeEach
    void setUp() {
        office = new TicketingOffice("Red", 50.0, 25.0);
    }

    @Test
    void testConstructor() {
        assertEquals("Red", office.getColor());
        assertEquals(50.0, office.getLength(), 0.001);
        assertEquals(25.0, office.getWidth(), 0.001);
        assertEquals("Ticketing Office", office.getBuildingType());
    }

    @Test
    void testSetSize() {
        office.setSize(60.0, 30.0);
        assertEquals(60.0, office.getLength(), 0.001);
        assertEquals(30.0, office.getWidth(), 0.001);
    }

    @Test
    void testSetColor() {
        office.setColor("Blue");
        assertEquals("Blue", office.getColor());
    }

    @Test
    void testSetBuildingType() {
        office.setBuildingType("Office");
        assertEquals("Office", office.getBuildingType());
    }

    @Test
    void testToString() {
        String expected = "Building Type: Ticketing Office, Color: Red, Length: 50.00, Width: 25.00";
        assertEquals(expected, office.toString());
    }
}