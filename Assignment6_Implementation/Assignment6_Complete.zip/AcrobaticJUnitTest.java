import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class AcrobaticJUnitTest {

    @Test
    public void testConstructorAndInheritedGetters() {
        Acrobatic acrobatic = new Acrobatic("Mike Bell", 30, 8, "Trapeze Artist");

        // Test inherited fields and getters
        assertEquals("Mike Bell", acrobatic.getName());
        assertEquals(30, acrobatic.getAge());
        assertEquals(8, acrobatic.getYearsWorked());

        // Test Acrobatic-specific field
        assertEquals("Trapeze Artist", acrobatic.getJob());
    }

    @Test
    public void testToString() {
        Acrobatic acrobatic = new Acrobatic("Alice Brown", 35, 12, "Fire Breather");

        // Expected output based on your actual toString()
        String expected = "Name: Alice Brown, Age: 35, Years Worked: 12, Job: Fire Breather";

        assertEquals(expected, acrobatic.toString());
    }
}