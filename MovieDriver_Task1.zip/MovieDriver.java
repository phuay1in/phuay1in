import java.util.Scanner;

public class MovieDriver {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);

        Movie movie = new Movie();

        System.out.println("Enter the name of a movie");
        String title = keyboard.nextLine();
        movie.setTitle(title);

        System.out.println("Enter the rating of the movie");
        String rating = keyboard.nextLine();
        movie.setRating(rating);

        System.out.println("Enter the number of tickets sold for this movie");
        int ticketsSold = keyboard.nextInt();
        movie.setSoldTickets(ticketsSold);

        System.out.println("\nMovie Information:");
        System.out.println(movie);

        keyboard.close();
    }
}