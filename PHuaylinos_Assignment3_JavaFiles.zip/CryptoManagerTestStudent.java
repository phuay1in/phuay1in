import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

public class CryptoManagerTestStudent {

    @Test
    public void testIsStringInBoundsValid() {
        assertTrue(CryptoManager.isStringInBounds("HELLO WORLD!"), "Valid string should return true");
        assertTrue(CryptoManager.isStringInBounds("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_"));
    }

    @Test
    public void testIsStringInBoundsInvalid() {
        assertFalse(CryptoManager.isStringInBounds("hello"), "Lowercase letters are out of bounds");
        assertFalse(CryptoManager.isStringInBounds("áéíóú"), "Non-ASCII characters are out of bounds");
    }

    @Test
    public void testVigenereEncryptionDecryption() {
        String key = "KEY";
        String plaintext = "HELLO WORLD!";
        String encrypted = CryptoManager.vigenereEncryption(plaintext, key);
        String decrypted = CryptoManager.vigenereDecryption(encrypted, key);
        assertNotEquals(plaintext, encrypted, "Encrypted text should not equal plaintext");
        assertEquals(plaintext, decrypted, "Decrypted text should match original plaintext");
    }

    @Test
    public void testPlayfairEncryptionDecryption() {
        String key = "MNT132!";
        String plaintext = "MONTGOMERY 2025!";
        String encrypted = CryptoManager.playfairEncryption(plaintext, key);
        String decrypted = CryptoManager.playfairDecryption(encrypted, key);
        assertNotEquals(plaintext, encrypted, "Encrypted text should not equal plaintext");
        assertEquals(plaintext + "X", decrypted, "Decrypted text should match original plaintext plus padding if odd length");
    }

    @Test
    public void testCaesarEncryptionDecryption() {
        String plaintext = "HELLO WORLD!";
        int key = 5;
        String encrypted = CryptoManager.caesarEncryption(plaintext, key);
        String decrypted = CryptoManager.caesarDecryption(encrypted, key);
        assertNotEquals(plaintext, encrypted, "Encrypted text should not equal plaintext");
        assertEquals(plaintext, decrypted, "Decrypted text should match original plaintext");
    }

    @Test
    public void testVigenereEncryptionOutOfBounds() {
        String key = "KEY";
        String plaintext = "hello"; // lowercase, out of bounds
        String result = CryptoManager.vigenereEncryption(plaintext, key);
        assertEquals("The selected string is not in bounds, Try again.", result);
    }

    @Test
    public void testPlayfairEncryptionOutOfBounds() {
        String key = "KEY";
        String plaintext = "hello"; // lowercase, out of bounds
        String result = CryptoManager.playfairEncryption(plaintext, key);
        assertEquals("The selected string is not in bounds, Try again.", result);
    }

    @Test
    public void testCaesarEncryptionOutOfBounds() {
        int key = 3;
        String plaintext = "hello"; // lowercase, out of bounds
        String result = CryptoManager.caesarEncryption(plaintext, key);
        assertEquals("The selected string is not in bounds, Try again.", result);
    }
}