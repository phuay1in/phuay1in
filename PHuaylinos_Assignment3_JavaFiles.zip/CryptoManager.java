/*
 * Class: CMSC203 
 * Instructor:
 * Description: (Give a brief description for each Class)
 * Due: 10/14/2025
 * Platform/compiler: Eclipse IDE
 * I pledge that I have completed the programming  assignment independently. 
*  I have not copied the code from a student or any source. 
*  I have not given my code to any student.
*  Print your Name here: Paul Huaylinos
*/




/**
 * This is a utility class that encrypts and decrypts a phrase using three
 * different approaches. 
 * 
 * The first approach is called the Vigenere Cipher.Vigenere encryption 
 * is a method of encrypting alphabetic text based on the letters of a keyword.
 * 
 * The second approach is Playfair Cipher. It encrypts two letters (a digraph) 
 * at a time instead of just one.
 * 
 * The third approach is Caesar Cipher. It is a simple replacement cypher. 
 * 
 * @author Paul Huaylinos
 * @version 8/3/2025
 */

public class CryptoManager { 

    private static final char LOWER_RANGE = ' ';
    private static final char UPPER_RANGE = '_';
    private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;
    // Use 64-character matrix (8X8) for Playfair cipher  
    private static final String ALPHABET64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_";

    public static boolean isStringInBounds(String plainText) {
        for (int i = 0; i < plainText.length(); i++) {
            if (!(plainText.charAt(i) >= LOWER_RANGE && plainText.charAt(i) <= UPPER_RANGE)) {
                return false;
            }
        }
        return true;
    }

	/**
	 * Vigenere Cipher is a method of encrypting alphabetic text 
	 * based on the letters of a keyword. It works as below:
	 * 		Choose a keyword (e.g., KEY).
	 * 		Repeat the keyword to match the length of the plaintext.
	 * 		Each letter in the plaintext is shifted by the position of the 
	 * 		corresponding letter in the keyword (A = 0, B = 1, ..., Z = 25).
	 */   

    public static String vigenereEncryption(String plainText, String key) {
        if (!isStringInBounds(plainText)) return "The selected string is not in bounds, Try again.";

        String encryptedText = "";
        for (int i = 0; i < plainText.length(); i++) {
            char ch = plainText.charAt(i);
            int shift = key.charAt(i % key.length()) - LOWER_RANGE;
            int encryptedChar = ((ch - LOWER_RANGE + shift) % RANGE) + LOWER_RANGE;
            encryptedText += (char) encryptedChar;
        }
        return encryptedText;
    }

    // Vigenere Decryption
    public static String vigenereDecryption(String encryptedText, String key) {
        if (!isStringInBounds(encryptedText)) return "The selected string is not in bounds, Try again.";

        String decryptedText = "";
        for (int i = 0; i < encryptedText.length(); i++) {
            char ch = encryptedText.charAt(i);
            int shift = key.charAt(i % key.length()) - LOWER_RANGE;
            int decryptedChar = ((ch - LOWER_RANGE - shift + RANGE) % RANGE) + LOWER_RANGE;
            decryptedText += (char) decryptedChar;
        }
        return decryptedText;
    }


	/**
	 * Playfair Cipher encrypts two letters at a time instead of just one.
	 * It works as follows:
	 * A matrix (8X8 in our case) is built using a keyword
	 * Plaintext is split into letter pairs (e.g., ME ET YO UR).
	 * Encryption rules depend on the positions of the letters in the matrix:
	 *     Same row: replace each letter with the one to its right.
	 *     Same column: replace each with the one below.
	 *     Rectangle: replace each letter with the one in its own row but in the column of the other letter in the pair.
	 */    

    public static String playfairEncryption(String plainText, String key) {
        if (!isStringInBounds(plainText)) return "The selected string is not in bounds, Try again.";

        char[][] matrix = buildPlayfairMatrix(key);
        String encryptedText = "";

        // Make plaintext length even by adding padding '*' if needed
        if (plainText.length() % 2 != 0) plainText += "*";

        for (int i = 0; i < plainText.length(); i += 2) {
            char a = plainText.charAt(i);
            char b = plainText.charAt(i + 1);

            int[] posA = findPosition(matrix, a);
            int[] posB = findPosition(matrix, b);

            if (posA[0] == posB[0]) { // Same row
                encryptedText += matrix[posA[0]][(posA[1] + 1) % 8];
                encryptedText += matrix[posB[0]][(posB[1] + 1) % 8];
            } else if (posA[1] == posB[1]) { // Same column
                encryptedText += matrix[(posA[0] + 1) % 8][posA[1]];
                encryptedText += matrix[(posB[0] + 1) % 8][posB[1]];
            } else { // Rectangle
                encryptedText += matrix[posA[0]][posB[1]];
                encryptedText += matrix[posB[0]][posA[1]];
            }
        }

        return encryptedText;
    }

    public static String playfairDecryption(String encryptedText, String key) {
        if (!isStringInBounds(encryptedText)) return "The selected string is not in bounds, Try again.";

        char[][] matrix = buildPlayfairMatrix(key);
        String decryptedText = "";

        for (int i = 0; i < encryptedText.length(); i += 2) {
            char a = encryptedText.charAt(i);
            char b = encryptedText.charAt(i + 1);

            int[] posA = findPosition(matrix, a);
            int[] posB = findPosition(matrix, b);

            if (posA[0] == posB[0]) { // Same row
                decryptedText += matrix[posA[0]][(posA[1] + 7) % 8]; // move left
                decryptedText += matrix[posB[0]][(posB[1] + 7) % 8];
            } else if (posA[1] == posB[1]) { // Same column
                decryptedText += matrix[(posA[0] + 7) % 8][posA[1]]; // move up
                decryptedText += matrix[(posB[0] + 7) % 8][posB[1]];
            } else { // Rectangle
                decryptedText += matrix[posA[0]][posB[1]];
                decryptedText += matrix[posB[0]][posA[1]];
            }
        }

        // Remove padding '*' if present at the end
        if (decryptedText.length() > 0 && decryptedText.charAt(decryptedText.length() - 1) == '*') {
            decryptedText = decryptedText.substring(0, decryptedText.length() - 1);
        }

        return decryptedText;
    }
    
    private static char[][] buildPlayfairMatrix(String key) {
        String used = "";
        String fullKey = "";

        // Add key characters (ignore duplicates)
        for (int i = 0; i < key.length(); i++) {
            char ch = key.charAt(i);
            if (!used.contains("" + ch)) {
                fullKey += ch;
                used += ch;
            }
        }

        // Add remaining characters from ALPHABET64
        for (int i = 0; i < ALPHABET64.length(); i++) {
            char ch = ALPHABET64.charAt(i);
            if (!used.contains("" + ch)) {
                fullKey += ch;
                used += ch;
            }
        }

        // Fill 8x8 matrix
        char[][] matrix = new char[8][8];
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                matrix[i][j] = fullKey.charAt(i * 8 + j);
            }
        }

        return matrix;
    }

    private static int[] findPosition(char[][] matrix, char ch) {
        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                if (matrix[i][j] == ch) return new int[]{i, j};
            }
        }
        return null;
    }
    
    /**
     * Caesar Cipher is a simple substitution cipher that replaces each letter in a message 
     * with a letter some fixed number of positions down the alphabet. 
     * For example, with a shift of 3, 'A' would become 'D', 'B' would become 'E', and so on.
     */    
 
    public static String caesarEncryption(String plainText, int key) {
        if (!isStringInBounds(plainText)) return "The selected string is not in bounds, Try again.";

        String encryptedText = "";
        for (int i = 0; i < plainText.length(); i++) {
            char ch = plainText.charAt(i);
            int encryptedChar = ((ch - LOWER_RANGE + key) % RANGE) + LOWER_RANGE;
            encryptedText += (char) encryptedChar;
        }
        return encryptedText;
    }

    // Caesar Decryption
    public static String caesarDecryption(String encryptedText, int key) {
        if (!isStringInBounds(encryptedText)) return "The selected string is not in bounds, Try again.";

        String decryptedText = "";
        for (int i = 0; i < encryptedText.length(); i++) {
            char ch = encryptedText.charAt(i);
            int decryptedChar = ((ch - LOWER_RANGE - key + RANGE) % RANGE) + LOWER_RANGE;
            decryptedText += (char) decryptedChar;
        }
        return decryptedText;
    }	    

}
